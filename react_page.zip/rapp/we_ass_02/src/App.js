import logo from './logo.svg';
import './App.css';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Column from './components/Column';
import Slider from './components/Slider';

function App() {
  return (
    <div className="App">
      <Navbar />
      <Slider/><br/><br/>
      <Column/><br/>
      <Footer />
    </div>
  );
}
export default App;
