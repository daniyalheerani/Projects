import React, { Component } from "react";

class Column extends React.Component {
    state = { }
    render () {
        return (
            <div className="container text-center">
  <div className="row align-items-start">
  <div class="col">
    <h3 className="text-center">Our Solar System</h3>
    <img src="https://static.scientificamerican.com/dam/m/128e9a2bf8a1939/original/DM0HT8_WEB.jpg?w=600" height="300px" width="350px" className="img-fluid" alt="..." />
    </div>
    <div class="col">
    <h3 className="text-center">Universe</h3>
    <img src="https://cdn.mos.cms.futurecdn.net/TarH6Nkf4tBo99QFQKRdLf-1200-80.jpg" height="300px" width="350px" className="img-fluid" alt="..." />
    </div>
    <div class="col">
    <h3 className="text-center">Aeronautics</h3>
    <img src="https://www.flyingmag.com/uploads/2022/07/shutterstock_559714906-scaled.jpg" height="300px" width="350px" className="img-fluid" alt="..." />

    </div>
 </div>
</div>


            );
        }
        }
        
        
        export default Column;