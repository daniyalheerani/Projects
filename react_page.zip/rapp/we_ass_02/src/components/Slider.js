import React, { Component } from "react";

class Slider extends React.Component {
    state = { }
    render () {
        return (
            <div id="carouselExampleIndicators" className="carousel slide">
  <div className="carousel-indicators">
    <button
      type="button"
      data-bs-target="#carouselExampleIndicators"
      data-bs-slide-to={0}
      className="active"
      aria-current="true"
      aria-label="Slide 1"
    />
    <button
      type="button"
      data-bs-target="#carouselExampleIndicators"
      data-bs-slide-to={1}
      aria-label="Slide 2"
    />
    <button
      type="button"
      data-bs-target="#carouselExampleIndicators"
      data-bs-slide-to={2}
      aria-label="Slide 3"
    />
  </div>
  <div className="carousel-inner">
    <div className="carousel-item active">
      <img src="https://images-assets.nasa.gov/image/iss069e018537/iss069e018537~large.jpg?w=1536&h=1024&fit=crop&crop=faces%2Cfocalpoint" height='640px' width='1080px' className="d-block w-100" alt="..." />
    </div>
    <div className="carousel-item">
      <img src="https://www.nasa.gov/wp-content/uploads/2024/03/fy25-budget-cover-no-text.png?resize=768,432" height='640px' width='1080px' className="d-block w-100" alt="..." />
    </div>
    <div className="carousel-item">
      <img src="https://c02.purpledshub.com/uploads/sites/41/2023/07/spiral-galaxy-7d50419.jpg?w=940&webp=1" height='640px' width='1080px' className="d-block w-100" alt="..." />
    </div>
  </div>
  <button
    className="carousel-control-prev"
    type="button"
    data-bs-target="#carouselExampleIndicators"
    data-bs-slide="prev"
  >
    <span className="carousel-control-prev-icon" aria-hidden="true" />
    <span className="visually-hidden">Previous</span>
  </button>
  <button
    className="carousel-control-next"
    type="button"
    data-bs-target="#carouselExampleIndicators"
    data-bs-slide="next"
  >
    <span className="carousel-control-next-icon" aria-hidden="true" />
    <span className="visually-hidden">Next</span>
  </button>
</div>


            );
        }
        }
        
        
        export default Slider;