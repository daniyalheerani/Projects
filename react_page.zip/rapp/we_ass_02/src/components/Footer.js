import React, { Component } from "react";

class Footer extends React.Component {
    state = { }
    render () {
        return (
            <div className="card text-center">
  <div className="card-header"><h2>NASA EXPLORING</h2></div>
  <div className="card-body">
    <h5 className="card-title">Earth Information Center</h5>
    <p className="card-text">
    For more than 50 years, NASA satellites have provided data on Earth's land, water, air, temperature, and climate. NASA's Earth Information Center allows visitors to see how our planet is changing in six key areas: sea level rise and coastal impacts, health and air quality, wildfires, greenhouse gases, sustainable energy, and agriculture.
    </p>
    <a href="#" className="btn btn-primary">
      Go Top 
    </a>
  </div>
  <div className="card-footer text-body-secondary">1 days ago</div>
</div>


            );
        }
        }
        
        
        export default Footer;